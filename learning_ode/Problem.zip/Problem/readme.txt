Paste as it is on your command window
"y=3*rectangularPulse(0,7,t)+10*rectangularPulse(13,15,t);"
It is just a input forcing function